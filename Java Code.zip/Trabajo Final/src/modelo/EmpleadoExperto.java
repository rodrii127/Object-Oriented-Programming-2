package modelo;

import java.util.*;
import javax.persistence.*;

@Entity
@Table(name = "empleadoExperto")
public class EmpleadoExperto{
    
    @Id
    @Column(name = "codigoEmpleado")
    private int codigoEmpleado;
    
    @Column(name = "dni")
    private int dni;
    
    @Column(name = "nombreEmpleado")
    private String nombreEmpleado;
    
    @Column(name = "areaExperto")
    private String areaExperto;
    
    @Column(name = "cantidadDeReclamosResueltos")
    private int cantidadDeReclamosResultos = 0; //...se le asigna al experto que ha atendido más reclamos.
    
    @Column(name = "cantidadDeReclamosAsignados")
    private int cantidadDeReclamosAsignados = 0; //se lo da al experto que menos reclamos asignados tenga hasta el momento...
    
    @ManyToMany(fetch = FetchType.EAGER, cascade = {CascadeType.ALL})
    @JoinTable(name="empleadoExpertoservicio", joinColumns={@JoinColumn(name="IdempleadoExperto")}, 
                                                        inverseJoinColumns={@JoinColumn(name="Idservicio")})
    private List<Servicio> serviciosExperto; 
    
    
    @ManyToMany(fetch = FetchType.EAGER, cascade = {CascadeType.ALL})
    @JoinTable(name="empleadoExpertotipoDeReclamo", joinColumns={@JoinColumn(name="IdempleadoExperto")}, 
                                                        inverseJoinColumns={@JoinColumn(name="IdipoDeReclamo")})
    private List<TipoDeReclamo> tiposDeReclamoExperto;
    //"Cada empleado (experto) tiene una tiene una lista de servicios y tipos de reclamos en el cual es experto".
    
    
    @OneToMany(mappedBy="empleadoEncargado",cascade= CascadeType.ALL)
    private List<Reclamo> reclamos;
    
    
    public EmpleadoExperto(){
        
    }
    
    public EmpleadoExperto(String nombreEmpleado, int codigoEmpleado, int dni, String areaExperto, 
            List<Servicio> serviciosExperto, List<TipoDeReclamo> tiposDeReclamoExperto) {
        this.setCodigoEmpleado(codigoEmpleado);
        this.setDni(dni);
        this.setNombreEmpleado(nombreEmpleado);
        this.setAreaExperto(areaExperto);
        this.setServiciosExperto(serviciosExperto);
        this.setTiposDeReclamoExperto(tiposDeReclamoExperto);
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public int getCodigoEmpleado() {
        return codigoEmpleado;
    }

    public void setCodigoEmpleado(int codigoEmpleado) {
        this.codigoEmpleado = codigoEmpleado;
    }

    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public void setNombreEmpleado(String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }

    
    
    
    public String getAreaExperto() {
        return areaExperto;
    }

    public void setAreaExperto(String areaExperto) {
        this.areaExperto = areaExperto;
    }

    public List<Servicio> getServiciosExperto() {
        return serviciosExperto;
    }

    public void setServiciosExperto(List<Servicio> serviciosExperto) {
        this.serviciosExperto = serviciosExperto;
    }

    public List<TipoDeReclamo> getTiposDeReclamoExperto() {
        return tiposDeReclamoExperto;
    }

    public void setTiposDeReclamoExperto(List<TipoDeReclamo> tiposDeReclamoExperto) {
        this.tiposDeReclamoExperto = tiposDeReclamoExperto;
    }

    /**
     * @return the cantidadDeReclamosResultos
     */
    public int getCantidadDeReclamosResultos() {
        return cantidadDeReclamosResultos;
    }

    /**
     * @param cantidadDeReclamosResultos the cantidadDeReclamosResultos to set
     */
    public void setCantidadDeReclamosResultos(int cantidadDeReclamosResultos) {
        this.cantidadDeReclamosResultos = cantidadDeReclamosResultos;
    }

    /**
     * @return the cantidadDeReclamosAsignados
     */
    public int getCantidadDeReclamosAsignados() {
        return cantidadDeReclamosAsignados;
    }

    /**
     * @param cantidadDeReclamosAsignados the cantidadDeReclamosAsignados to set
     */
    public void setCantidadDeReclamosAsignados(int cantidadDeReclamosAsignados) {
        this.cantidadDeReclamosAsignados = cantidadDeReclamosAsignados;
    }
    
}
