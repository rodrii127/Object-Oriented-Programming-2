package modelo;

public class SupervisorDeArea{
    
    private int codigoEmpleado;
    
    private String nombreEmpleado;
    
    private int dni;
    
    private int numeroPuesto;
    
    public SupervisorDeArea(){
        
    }
    
    public SupervisorDeArea(String nombreEmpleado, int codigoEmpleado, int dni, int numeroPuesto) {
        this.setCodigoEmpleado(codigoEmpleado);
        this.setDni(dni);
        this.setNombreEmpleado(nombreEmpleado);
        this.setNumeroPuesto(numeroPuesto);
    }

    public int getCodigoEmpleado() {
        return codigoEmpleado;
    }

    public void setCodigoEmpleado(int codigoEmpleado) {
        this.codigoEmpleado = codigoEmpleado;
    }

    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public void setNombreEmpleado(String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    
    
    
    public int getNumeroPuesto() {
        return numeroPuesto;
    }

    public void setNumeroPuesto(int numero_puesto) {
        this.numeroPuesto = numero_puesto;
    }
    
    
    
}
