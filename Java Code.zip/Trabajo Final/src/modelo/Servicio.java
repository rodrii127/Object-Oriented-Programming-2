package modelo;

import java.util.*;
import javax.persistence.*;


@Entity
@Table(name = "servicio")
public class Servicio {
    
    @Id
    @Column(name = "codigoServicio")
    private int codigoServicio;
    
    @Column(name = "nombreServicio")
    private String nombreServicio;
    
    @Column(name = "precio")
    private float precio;
    
    @ManyToMany(cascade = {CascadeType.ALL},mappedBy="serviciosExperto")
    List<EmpleadoExperto> empleadosExpertos;
    
    @OneToMany(mappedBy="miServicio",cascade= CascadeType.ALL)
    private List<Reclamo> reclamos;
    
    public Servicio(){
        
    }
    
    public Servicio(String nombreServicio, int codigoServicio, float precio){
        this.setCodigoServicio(codigoServicio);
        this.setNombreServicio(nombreServicio);
        this.setPrecio(precio);
    }

    public String getNombreServicio() {
        return nombreServicio;
    }

    public void setNombreServicio(String nombreServicio) {
        this.nombreServicio = nombreServicio;
    }

    public int getCodigoServicio() {
        return codigoServicio;
    }

    public void setCodigoServicio(int codigoServicio) {
        this.codigoServicio = codigoServicio;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }
}
