    package modelo;

import java.time.LocalDate;
import java.util.*;
import javax.persistence.*;

@Entity
@Table(name = "reclamo")
public class Reclamo {
    
    @Id
    @Column (name = "codigoReclamo")
    private int codigoReclamo;
    
    @Column (name = "resuelto")
    private boolean resuelto;
    
    @Column (name = "fechaReclamo")
    private String fechaDeReclamo;
    
    @Column (name = "descripcion")
    private String descripcion;
    
    @Column (name = "urgente")
    private boolean urgente; //"Debe tener una clasificacion a criterio del empleado de si es urgente o no el reclamo..."
    
    @ManyToOne
    @JoinColumn(name="Idservicio")
    private Servicio miServicio;
    
    @ManyToOne
    @JoinColumn(name="Idcliente")
    private Cliente miCliente;
    
    @ManyToOne
    @JoinColumn(name="IdtipoDeReclamo")
    private TipoDeReclamo tipoDeReclamo;
    
    @ManyToOne
    @JoinColumn(name="IdempleadoDeAtencion")
    private EmpleadoDeAtencion miEmpleado;
    
    @ManyToOne
    @JoinColumn(name="IdempleadoExperto")
    private EmpleadoExperto empleadoEncargado;
    
    @OneToMany(mappedBy="miReclamo",cascade= CascadeType.ALL)
    private List<EstadoDeReclamo> estadosDelReclamo; 
    //"Esta consulta debe permitir visualizar todos los estados por los que haya atravesado el reclamo y su situación actual..."
    
    public Reclamo(){
        
    }
    
    public Reclamo(int codigoReclamo,String fechaDeReclamo ,String descripcion, Servicio miServicio,
                   TipoDeReclamo tipoDeReclamo, EmpleadoDeAtencion miEmpleado, boolean urgente, Cliente miCliente){
        
        this.setCodigoReclamo(codigoReclamo);
        this.setFechaDeReclamo(fechaDeReclamo);
        this.setDescripcion(descripcion);
        this.setMiServicio(miServicio);
        this.setTipoDeReclamo(tipoDeReclamo);
        this.setMiEmpleado(miEmpleado);
        this.setUrgente(urgente);
        this.setMiCliente(miCliente);
    }

    public Cliente getMiCliente() {
        return miCliente;
    }

    public void setMiCliente(Cliente miCliente) {
        this.miCliente = miCliente;
    }

    public boolean isResuelto() {
        return resuelto;
    }

    public void setResuelto(boolean resuelto) {
        this.resuelto = resuelto;
    }

    public int getCodigoReclamo() {
        return codigoReclamo;
    }

    public void setCodigoReclamo(int codigoReclamo) {
        this.codigoReclamo = codigoReclamo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public TipoDeReclamo getTipoDeReclamo() {
        return tipoDeReclamo;
    }

    public void setTipoDeReclamo(TipoDeReclamo tipoDeReclamo) {
        this.tipoDeReclamo = tipoDeReclamo;
    }

    public EmpleadoDeAtencion getMiEmpleado() {
        return miEmpleado;
    }

    public void setMiEmpleado(EmpleadoDeAtencion miEmpleado) {
        this.miEmpleado = miEmpleado;
    }

    public boolean isUrgente() {
        return urgente;
    }

    public void setUrgente(boolean urgente) {
        this.urgente = urgente;
    }

    public String getFechaDeReclamo() {
        return fechaDeReclamo;
    }

    public void setFechaDeReclamo(String fechaDeReclamo) {
        this.fechaDeReclamo = fechaDeReclamo;
    }

    public EmpleadoExperto getEmpleadoEncargado() {
        return empleadoEncargado;
    }

    public void setEmpleadoEncargado(EmpleadoExperto empleadoEncargado) {
        this.empleadoEncargado = empleadoEncargado;
    }

    public List<EstadoDeReclamo> getEstadosDelReclamo() {
        return estadosDelReclamo;
    }

    public void setEstadosDelReclamo(List<EstadoDeReclamo> estadosDelReclamo) {
        this.estadosDelReclamo = estadosDelReclamo;
    }

    /**
     * @return the miServicio
     */
    public Servicio getMiServicio() {
        return miServicio;
    }

    /**
     * @param miServicio the miServicio to set
     */
    public void setMiServicio(Servicio miServicio) {
        this.miServicio = miServicio;
    }
    
}
