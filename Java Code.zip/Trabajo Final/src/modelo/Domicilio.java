package modelo;

import javax.persistence.*;

@Entity
@Table(name = "domicilio")
public class Domicilio {
    
    @Id
    @Column(name = "numeroCasa" )
    private int numeroCasa;
    
    @Column(name = "ciudad" )
    private String ciudad; 
    
    @Column(name = "calle" )
    private String calle;
    
    @OneToOne(cascade=CascadeType.ALL)
    @PrimaryKeyJoinColumn
    private Cliente miCliente;
    
    @OneToOne(cascade=CascadeType.ALL)
    @PrimaryKeyJoinColumn    
    private EmpleadoExperto miEmpleado;
    
    public Domicilio(){
        
    }
    
    public Domicilio(String ciudad, String calle, int numeroCasa){
        this.setCalle(calle);
        this.setCiudad(ciudad);
        this.setNumeroCasa(numeroCasa);
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getCalle() {
       return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public int getNumeroCasa() {
        return numeroCasa;
    }

    public void setNumeroCasa(int numeroCasa) {
        this.numeroCasa = numeroCasa;
    }

    public Cliente getMiCliente() {
        return miCliente;
    }

    public void setMiCliente(Cliente miCliente) {
        this.miCliente = miCliente;
    }

    public EmpleadoExperto getMiEmpleado() {
        return miEmpleado;
    }

    public void setMiEmpleado(EmpleadoExperto miEmpleado) {
        this.miEmpleado = miEmpleado;
    }
    
    
}
