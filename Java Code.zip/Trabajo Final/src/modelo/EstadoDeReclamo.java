package modelo;

import javax.persistence.*;

@Entity
@Table(name = "estadoDeReclamo")
public class EstadoDeReclamo {
    
    @Id
    @Column(name = "codigoEstado")
    private int codigoEstado;
    
    @Column(name = "formaResolver")
    private String formaResolver;
    
    @Column(name = "estado")
    private String estado;
    
    @Column(name = "motivoTransferencia")
    private String motivoTransferencia;
    
    @ManyToOne
    @JoinColumn(name="Idereclamo")
    Reclamo miReclamo ;
    
    public EstadoDeReclamo(){
        
    }
    
    public EstadoDeReclamo(int codigoEstado, String formaResolver,String estado,String motivoTransferencia){
        this.setCodigoEstado(codigoEstado);
        this.setEstado(estado);
        this.setFormaResolver(formaResolver);
        this.setMotivoTransferencia(motivoTransferencia);
    }

    public Reclamo getMiReclamo() {
        return miReclamo;
    }

    public void setMiReclamo(Reclamo miReclamo) {
        this.miReclamo = miReclamo;
    }
    
    
    
    public int getCodigoEstado() {
        return codigoEstado;
    }

    public void setCodigoEstado(int codigoEstado) {
        this.codigoEstado = codigoEstado;
    }

    
    
    public String getFormaResolver() {
        return formaResolver;
    }

    public void setFormaResolver(String formaResolver) {
        this.formaResolver = formaResolver;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getMotivoTransferencia() {
        return motivoTransferencia;
    }

    public void setMotivoTransferencia(String motivoTransferencia) {
        this.motivoTransferencia = motivoTransferencia;
    }

}
