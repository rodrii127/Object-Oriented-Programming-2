package modelo;

import java.util.*;
import javax.persistence.*;

@Entity
@Table(name = "tipoDeReclamo")
public class TipoDeReclamo {
    
    
    @Id
    @Column(name = "codigoTipoReclamo")
    private int codigoTipoReclamo;
    
    @Column(name = "nombreTipoReclamo")
    private String nombreTipoReclamo;
    
    @ManyToMany(cascade = {CascadeType.ALL},mappedBy="tiposDeReclamoExperto")
    private List<EmpleadoExperto> empleadosExpertos = new ArrayList<EmpleadoExperto>();
    
    @OneToMany(mappedBy="tipoDeReclamo",cascade= CascadeType.ALL)
    private List<Reclamo> reclamos;
    
    public TipoDeReclamo(){
        
    }
    
    public TipoDeReclamo(String nombreTipoReclamo, int codigoTipoReclamo){
        this.setCodigoTipoReclamo(codigoTipoReclamo);
        this.setNombreTipoReclamo(nombreTipoReclamo);
    }

    public String getNombreTipoReclamo() {
        return nombreTipoReclamo;
    }

    public void setNombreTipoReclamo(String nombreTipoReclamo) {
        this.nombreTipoReclamo = nombreTipoReclamo;
    }

    public int getCodigoTipoReclamo() {
        return codigoTipoReclamo;
    }

    public void setCodigoTipoReclamo(int codigoTipoReclamo) {
        this.codigoTipoReclamo = codigoTipoReclamo;
    }
}
