package modelo;

import java.util.*;
import javax.persistence.*;

@Entity
@Table(name = "cliente")
public class Cliente {
    
    @Id
    @Column(name = "codigoCliente")
    private int codigoCliente;
    
    @Column(name = "nombreCliente")
    private String nombreCliente;
    
    @Column (name = "dni")
    private int dni;
    
    @OneToMany(mappedBy="miCliente",cascade= CascadeType.MERGE)
    private List<Reclamo> reclamo;
    
    public Cliente(){
        
    }
    
    public Cliente(String nombreCliente, int dni, int codigoCliente){
        this.setCodigoCliente(codigoCliente);
        this.setDni(dni);
        this.setNombreCliente(nombreCliente);
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public int getCodigoCliente() {
        return codigoCliente;
    }

    public void setCodigoCliente(int codigoCliente) {
        this.codigoCliente = codigoCliente;
    }
    
    
}
