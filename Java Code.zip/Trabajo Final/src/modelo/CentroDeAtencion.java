package modelo;

import java.util.*;

public class CentroDeAtencion {

    /**
     * @return the misEmpleadosDeAtencion
     */
    public List<EmpleadoDeAtencion> getMisEmpleadosDeAtencion() {
        return misEmpleadosDeAtencion;
    }

    /**
     * @param misEmpleadosDeAtencion the misEmpleadosDeAtencion to set
     */
    public void setMisEmpleadosDeAtencion(List<EmpleadoDeAtencion> misEmpleadosDeAtencion) {
        this.misEmpleadosDeAtencion = misEmpleadosDeAtencion;
    }
    
    //VER CUAL USAMOS, SI LIST - MAP - SET
    private List<Servicio> misServicios = new ArrayList<Servicio>();
    private List<Cliente> misClientes = new ArrayList<Cliente>();
    private List<Reclamo> misReclamos = new ArrayList<Reclamo>();
    private List<EmpleadoDeAtencion> misEmpleadosDeAtencion = new ArrayList<>();
    private List<EmpleadoExperto> misEmpleadosExpertos = new ArrayList<>();
    private List<TipoDeReclamo> misTiposDeReclamo = new ArrayList<>();

    public CentroDeAtencion (){
        
    }
    
    public List<Servicio> getMisServicios() {
        return misServicios;
    }

    public void setMisServicios(List<Servicio> misServicios) {
        this.misServicios = misServicios;
    }

    public List<Cliente> getMisClientes() {
        return misClientes;
    }

    public void setMisClientes(List<Cliente> misClientes) {
        this.misClientes = misClientes;
    }

    public List<Reclamo> getMisReclamos() {
        return misReclamos;
    }

    public void setMisReclamos(List<Reclamo> misReclamos) {
        this.misReclamos = misReclamos;
    }

    public List<TipoDeReclamo> getMisTiposDeReclamo() {
        return misTiposDeReclamo;
    }

    public void setMisTiposDeReclamo(List<TipoDeReclamo> misTiposDeReclamo) {
        this.misTiposDeReclamo = misTiposDeReclamo;
    }

    public List<EmpleadoExperto> getMisEmpleadosExpertos() {
        return misEmpleadosExpertos;
    }

    public void setMisEmpleadosExpertos(List<EmpleadoExperto> misEmpleadosExpertos) {
        this.misEmpleadosExpertos = misEmpleadosExpertos;
    }
}
