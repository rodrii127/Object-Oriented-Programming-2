package modelo;

import java.util.List;
import javax.persistence.*;

@Entity
@Table(name = "empleadoDeAtencion")
public class EmpleadoDeAtencion{
    
    @Id
    @Column(name = "codigoEmpleado")
    private int codigoEmpleado;
    
    @Column(name = "nombreEmpleado")
    private String nombreEmpleado;
    
    @Column(name = "dni")
    private int dni;
    
    @Column(name = "numeroPuesto")
    private int numeroPuesto;
    
    @OneToMany(mappedBy="miEmpleado",cascade= CascadeType.ALL)
    private List<Reclamo> reclamos;
    
    public EmpleadoDeAtencion(){
        
    }
    
    public EmpleadoDeAtencion(String nombreEmpleado, int codigoEmpleado, int dni, int numeroPuesto) {
        this.setCodigoEmpleado(codigoEmpleado);
        this.setNombreEmpleado(nombreEmpleado);
        this.setDni(dni);
        this.setNumeroPuesto(numeroPuesto);
    }

    
    
    
    public int getNumeroPuesto() {
        return numeroPuesto;
    }

    public int getCodigoEmpleado() {
        return codigoEmpleado;
    }

    public void setCodigoEmpleado(int codigoEmpleado) {
        this.codigoEmpleado = codigoEmpleado;
    }

    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public void setNombreEmpleado(String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public void setNumeroPuesto(int numeroPuesto) {
        this.numeroPuesto = numeroPuesto;
    }
    
    
    
}
