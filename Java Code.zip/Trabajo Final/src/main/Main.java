package main;
import modelo.*;
import controlador.*;
import java.util.*;
import vista.*;

public class Main {
    
    public static void main (String[] args){
        
        ControladorDePersistencia persistencia = new ControladorDePersistencia();
        CentroDeAtencion miCentroDeAtencion = new CentroDeAtencion();
        ControladorPrincipal miControlador = new ControladorPrincipal (miCentroDeAtencion, persistencia);
        VentanaPrincipal miVentana = new VentanaPrincipal(miControlador, persistencia);
    }
    
}
