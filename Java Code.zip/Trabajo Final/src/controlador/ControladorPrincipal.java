package controlador;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import modelo.*;
import java.util.*;
import modelo.Reclamo;

public class ControladorPrincipal {
    
    private CentroDeAtencion miCentroDeAtencion;
    private ControladorDePersistencia persistencia;
    
    public ControladorPrincipal(CentroDeAtencion miCentroDeAtencion, ControladorDePersistencia persis){
        this.miCentroDeAtencion = miCentroDeAtencion;
        this.persistencia = persis;
    }
    
    
    //Registrar reclamo
    public int RegistrarReclamo(String nombreServicio, String descipcion, int dniCliente, 
                                    String nombreTipoReclamo, boolean urgente, int codigoEmpleado){
        
        String mensaje = "No se pudo crear el reclamo";
        
            //Asigna un numero correlativo a cada reclamo registrado.
            List<Reclamo> misReclamos = persistencia.cargarReclamos();
            
            int codigoReclamo = 0;
            
            if(misReclamos.size() == 0){
                codigoReclamo = 1;
            }
            else{
                codigoReclamo = (misReclamos.get((misReclamos.size() -1)).getCodigoReclamo() + 1);
            }
            
            

            LocalDate fechaReclamo = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd LLLL yyyy");
            String formattedString = fechaReclamo.format(formatter);
            
            Servicio miServicio = new Servicio();
            TipoDeReclamo miTipoDeReclamo = new TipoDeReclamo();
            EmpleadoDeAtencion miEmpleado = new EmpleadoDeAtencion();
            Cliente miCliente = new Cliente();
            List<EstadoDeReclamo> misEstados = new ArrayList<>();
            
            
            for(Cliente c: persistencia.cargarClientes()){
                if(c.getDni()== dniCliente){
                    miCliente = c;
                }
            }
            
            for(Servicio s: persistencia.cargarServicios()){
                if(s.getNombreServicio().equals(nombreServicio)){
                    miServicio = s;
                }
            }

            for(TipoDeReclamo t: persistencia.cargarTiposReclamo()){
                if(t.getNombreTipoReclamo().equals(nombreTipoReclamo)){
                    miTipoDeReclamo = t;
                }
            }

            for(EmpleadoDeAtencion e: persistencia.cargarEmpleadoAtencion()){
                if(e.getCodigoEmpleado() == codigoEmpleado){
                    miEmpleado = e;
                }
            }
            
            int numero = (int) (Math.random() * 100000) + 1;
            
            EstadoDeReclamo miEstado = new EstadoDeReclamo( numero ," ", "alta", " ");
            
            Reclamo miReclamo = new Reclamo(codigoReclamo, formattedString, descipcion, miServicio, miTipoDeReclamo, 
                                            miEmpleado, urgente, miCliente);
            
            miReclamo.setResuelto(false);
            miEstado.setMiReclamo(miReclamo);
            miReclamo.setEmpleadoEncargado(this.asignarReclamo(miTipoDeReclamo, miServicio, miReclamo));
            persistencia.persistirInstancia(miReclamo);
            persistencia.persistirInstancia(miEstado);
            return codigoReclamo;
    }
    
    
    //Asignar reclamo a un empleado experto
    public EmpleadoExperto asignarReclamo(TipoDeReclamo tipoDeReclamo, Servicio service, Reclamo reclamoNuevo){
        
        List<EmpleadoExperto> misEmpleadosExpertos = persistencia.cargarEmpleadoExperto();
        List<EmpleadoExperto> misEmpleadosElegidos = new ArrayList<EmpleadoExperto>();
        EmpleadoExperto empleadoElegido = new EmpleadoExperto();
        empleadoElegido.setCantidadDeReclamosAsignados(0);
        
        Reclamo miReclamo = reclamoNuevo;
        Servicio miServicio = service;
        TipoDeReclamo miTipoDeReclamo = tipoDeReclamo;
        
        for (EmpleadoExperto empleado : misEmpleadosExpertos) {
            for(int i = 0; i < empleado.getServiciosExperto().size(); i++ ){
                for(int j=0; j < empleado.getTiposDeReclamoExperto().size(); j++){
                    if(empleado.getServiciosExperto().get(i).getNombreServicio().equals(miServicio.getNombreServicio()) && 
                            empleado.getTiposDeReclamoExperto().get(j).getNombreTipoReclamo().equals(miTipoDeReclamo.getNombreTipoReclamo())){
                        
                        misEmpleadosElegidos.add(empleado);
                        
                    }
                }
            }
        }
        
        empleadoElegido = misEmpleadosElegidos.get(0);
        
        for (EmpleadoExperto employer : misEmpleadosElegidos) {
            if(misEmpleadosElegidos.size() == 1){
                break;
            }
            else{
                if(empleadoElegido.getCantidadDeReclamosAsignados() > employer.getCantidadDeReclamosAsignados()){
                    empleadoElegido = employer;
                }
            }
        }
        
        return empleadoElegido;
    }
    
    
    
    //Módulo necesario para finalizar un reclamo..
    public boolean finalizarReclamo(int codigoReclamo, String formaResolver){
        
        List<Reclamo> lista = persistencia.cargarReclamos();
        Reclamo miReclamo = new Reclamo();
        boolean anduvoOno = false;
        
        String estado = "Finalizado";
        String motivoTransferencia = " ";
        for(Reclamo r : lista){
            if(r.getCodigoReclamo() == codigoReclamo){
                int numero = (r.getEstadosDelReclamo().get(r.getEstadosDelReclamo().size() -1).getCodigoEstado() + 1 );
                EstadoDeReclamo estadoDeReclamo = new EstadoDeReclamo(numero ,formaResolver, estado, motivoTransferencia);
                miReclamo = r;
                miReclamo.getEstadosDelReclamo().add(estadoDeReclamo);
                anduvoOno = true;
                break;
            }
            anduvoOno = false;
        }
        miReclamo.setResuelto(true);
        persistencia.persistirInstancia(miReclamo);    
        
        return anduvoOno;
    }
    
    
    
    //Transferir reclamo a otro empleado experto
    public boolean transferirReclamos (int codigoReclamo, String motivoTransferencia, int codigoEmpleado){
        
        List<Reclamo> lista = persistencia.cargarReclamos();
        Reclamo miReclamo = new Reclamo();
        boolean anduvoOno = false;
        String estado = "En Proceso";
        
        for(Reclamo r : lista){
            if(r.getCodigoReclamo() == codigoReclamo){
                int numero = (r.getEstadosDelReclamo().get(r.getEstadosDelReclamo().size() -1).getCodigoEstado() + 1 );
                EstadoDeReclamo estadoDeReclamo = new EstadoDeReclamo(numero ,"No se resolvió", estado, motivoTransferencia);
                miReclamo = r;
                miReclamo.getEstadosDelReclamo().add(estadoDeReclamo);
                anduvoOno = true;
                break;
            }
            anduvoOno = false;
        }
        
        EmpleadoExperto miEmpleadoExperto = new EmpleadoExperto();
        boolean anduvoOno2 = false;
        
        for(EmpleadoExperto e: persistencia.cargarEmpleadoExperto()){
                if(e.getCodigoEmpleado() == codigoEmpleado ){
                    miEmpleadoExperto = e;
                    miReclamo.setEmpleadoEncargado(miEmpleadoExperto);
                    anduvoOno2 = true;
                }
        }
        return (anduvoOno && anduvoOno2);
    }
    
    
    
    
    //Traer reclamos de un cliente
    public List<Reclamo> reclamosDeCliente(int dniCliente){
        List<Reclamo> todosLosReclamos = persistencia.cargarReclamos();
        List<Reclamo> reclamosDeCliente = new ArrayList<Reclamo>();
        
        for (Reclamo reclamo : todosLosReclamos) {
            if(reclamo.getMiCliente().getDni() == dniCliente){
                reclamosDeCliente.add(reclamo);
            }
        }
        return reclamosDeCliente;
    }
    
    
    
    
    
    
    
    
    
    
    //Consultar estados de un reclamo
    public List<EstadoDeReclamo> consultarReclamoCliente(int codigoCliente, int codigoReclamo){
        List<EstadoDeReclamo> lista = new ArrayList<EstadoDeReclamo>();
        int i =0;
        
        for(Reclamo r : miCentroDeAtencion.getMisReclamos()){
            if(miCentroDeAtencion.getMisReclamos().get(i).getMiCliente().getCodigoCliente() == codigoCliente
                        && miCentroDeAtencion.getMisReclamos().get(i).getCodigoReclamo() == codigoReclamo){
                lista = miCentroDeAtencion.getMisReclamos().get(i).getEstadosDelReclamo();
                break;
            }
            i++;
        }
        return lista;
    }
    
    
    //Consultar todos los reclamos resueltos de un empleado
    public List<Reclamo> consultarReclamosResueltosEmpleado (int codigoEmpleado){
        List<Reclamo> lista = new ArrayList<Reclamo>();
        int i =0;
        for(Reclamo r : persistencia.cargarReclamos()){
            if(r.getEmpleadoEncargado().getCodigoEmpleado() == codigoEmpleado && r.isResuelto() == true){
                lista.add(r);
            }
        }
        return lista;
    }
    
    
    //Consultar todos los reclamos sin resolver de un empleado
    public List<Reclamo> consultarReclamosPendientesEmpleado (int codigoEmpleado){
        List<Reclamo> lista = new ArrayList<Reclamo>();
        
        for(Reclamo r : persistencia.cargarReclamos()){
            if(r.getEmpleadoEncargado() != null){
                if(r.getEmpleadoEncargado().getCodigoEmpleado() == codigoEmpleado && r.isResuelto() == false){
                    lista.add(r);
                }
            }
        }
        return lista;
    }
    
    
    //REGISTRO DE TODAS LAS CLASES
    public boolean registrarCliente(String nombre, int dni){
        
        List<Cliente> lista = persistencia.cargarClientes();
        
        int codigoCliente = 1;
        
        if(lista.size() == 0){
            codigoCliente = 1;
        }else{
            for (Cliente cliente : lista) {
                if(cliente.getDni()== dni){
                    return false;
                }
            }
            codigoCliente = (lista.get((lista.size() -1)).getCodigoCliente() + 1);
        }
        
        
        Cliente miCliente = new Cliente(nombre, dni, codigoCliente);
        persistencia.persistirInstancia(miCliente);
        
        return true;
    }
    
    
    
    public boolean registrarEmleadoExperto (String nombre, int dni, String areaExperto, 
                                            List<String> serviciosAñadidos, List <String> tiposDeReclamoAñadidos){
        
        List<EmpleadoExperto> lista = persistencia.cargarEmpleadoExperto();
        
        
        int codigoEmpleado = 1;
        
        if(lista.size() == 0){
            codigoEmpleado = 1;
        }else{
            for(EmpleadoExperto empleadoExperto : lista){
                if(empleadoExperto.getDni() == dni){
                    return false;
                }
            }
            codigoEmpleado = (lista.get((lista.size() -1)).getCodigoEmpleado() + 1);
        }
        
        List<Servicio> serviciosExperto = new ArrayList<Servicio>();
        List<Servicio> todosLosServicios = persistencia.cargarServicios();
        for (String service : serviciosAñadidos) {
            for (Servicio servicio : todosLosServicios) {
                if(servicio.getNombreServicio().equals(service)){
                    serviciosExperto.add(servicio);
                }
            }
        }
        
        List<TipoDeReclamo> tipoDeReclamos = new ArrayList<TipoDeReclamo>();
        List<TipoDeReclamo> todosLosTipos = persistencia.cargarTiposReclamo();
        for (String tipoReclamo : tiposDeReclamoAñadidos) {
            for (TipoDeReclamo tipo : todosLosTipos) {
                if(tipo.getNombreTipoReclamo().equals(tipoReclamo)){
                    tipoDeReclamos.add(tipo);
                }
            }
        }
        
        if(tipoDeReclamos.size() == 0 || serviciosExperto.size() == 0){
            return false;
        }
        
        EmpleadoExperto miEmpleadoExperto = new EmpleadoExperto(nombre, codigoEmpleado, dni, areaExperto, serviciosExperto, tipoDeReclamos);
        persistencia.persistirInstancia(miEmpleadoExperto);
        
        return true;
    }

    
    
    public boolean registrarEmpleadoAtencion (String nombre, int dni, int numeroPuesto){
        
        List<EmpleadoDeAtencion> lista = persistencia.cargarEmpleadoAtencion();
        
        int codigoEmpleado = 1;
        
        if(lista.size() == 0){
            codigoEmpleado = 1;
        }else{
            for (EmpleadoDeAtencion empleadoDeAtencion : lista) {
                if(empleadoDeAtencion.getDni() == dni){
                    return false;
                }
            }
            codigoEmpleado = (lista.get((lista.size() -1)).getCodigoEmpleado() + 1);
        }
        
        EmpleadoDeAtencion miEmpleado = new EmpleadoDeAtencion(nombre, codigoEmpleado, dni, numeroPuesto);
        persistencia.persistirInstancia(miEmpleado);
        
        return true;
    }
    
    
    
    
    public boolean registrarServicio (String nombreServicio, float precio){
        
        List<Servicio> lista = persistencia.cargarServicios();
        
        int codigoServicio = 1;
        
        if(lista.size() == 0){
            codigoServicio = 1;
        }else{
            for (Servicio service : lista) {
                if(service.getNombreServicio().equals(nombreServicio)){
                    return false;
                }
            }
            codigoServicio = (lista.get((lista.size() -1)).getCodigoServicio()+ 1);
        }
        
        Servicio miServicio = new Servicio(nombreServicio, codigoServicio, precio);
        persistencia.persistirInstancia(miServicio);
        
        return true;
    }
    
    public boolean registrarTipoDeReclamo (String nombreTipoReclamo){
        
        List<TipoDeReclamo> lista = persistencia.cargarTiposReclamo();
        
        int codigoTipoReclamo = 1;
        
        if(lista.size() == 0){
            codigoTipoReclamo = 1;
        }else{
            for (TipoDeReclamo tipo : lista) {
                if(tipo.getNombreTipoReclamo().equals(nombreTipoReclamo)){
                    return false;
                }
            }
            codigoTipoReclamo = (lista.get((lista.size() -1)).getCodigoTipoReclamo() + 1);
        }
        
        TipoDeReclamo miTipoReclamo = new TipoDeReclamo(nombreTipoReclamo, codigoTipoReclamo);
        persistencia.persistirInstancia(miTipoReclamo);
        
        return true;
    }
    
    
    
    //Métodos adicionales para cargar tablas
    public List<String> traerServicios(){
        List<String> servicio = new ArrayList<String>();
        List<Servicio> misServicios = persistencia.cargarServicios();
        
        for (Servicio misServicio : misServicios) {
            String nombre = misServicio.getNombreServicio();
            servicio.add(nombre);
        }
        
        return servicio;
    }
       
    
    public List<String> traerTiposDeReclamo(){
        List<String> tipoReclamo = new ArrayList<String>();
        List<TipoDeReclamo> misTiposReclamo = persistencia.cargarTiposReclamo();
        
        for (TipoDeReclamo miTipo : misTiposReclamo) {
            String nombre = miTipo.getNombreTipoReclamo();
            tipoReclamo.add(nombre);
        }
        
        return tipoReclamo;
    }
    
    
    public List<String> traerEstadosDeReclamo(String codigo){
        
        int codigoReclamo = Integer.parseInt(codigo);
        
        
        List<String> estadoReclamo = new ArrayList<String>();
        List<EstadoDeReclamo> misEstadosReclamo = persistencia.cargarEstadosDeReclamo();
        
        for (EstadoDeReclamo miEstado : misEstadosReclamo) {
            System.out.println(miEstado.getCodigoEstado());
            if(miEstado.getMiReclamo().getCodigoReclamo() == codigoReclamo){
                estadoReclamo.add(miEstado.getEstado());
            }
        }
        
        return estadoReclamo;
    }
    
}
