package controlador;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.persistence.Query;
import modelo.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class ControladorDePersistencia {
    
    private static final SessionFactory sessionfactory = buildSessionFactory();
    
    private static SessionFactory buildSessionFactory() {

            try {
                Configuration configuration = new Configuration();
                configuration.configure("hibernate.cfg.xml");
                ServiceRegistry serviceregistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();                    
                SessionFactory sessionfactory = configuration.buildSessionFactory(serviceregistry);
                return sessionfactory;
            } catch (Throwable e) {
                System.out.println("La creación de Session Factory a fallado "+e) ;
                throw new ExceptionInInitializerError();
            }        
        }

        public static SessionFactory getSessionfactory() {
            return sessionfactory;
    }

    
    public boolean persistirInstancia(Object instancia){
	boolean resultado = false;
                
        Session session = getSessionfactory().getCurrentSession();
        
        Transaction t = session.getTransaction();
        t.begin();
	try {
            
            session.saveOrUpdate(instancia);
            
            /*
            * Se comprueba que se haya persistido la instancia.
            */
            resultado = session.contains(instancia);

	} catch (Exception e) {
            System.out.println("No se pudo guardar la instancia "+e);
	}
        t.commit();

        return resultado;
    }
    
    public boolean eliminarInstancia(Object instancia){
		boolean resultado = false;

                Session session = getSessionfactory().getCurrentSession();
                Transaction t = session.getTransaction();
                t.begin();
                try {
                    
                    session.delete(instancia);
                    resultado = true;
                    
		} catch (Exception e) {
                    System.out.println("No se pudo eliminar la instancia"+e);
                }
                t.commit();
		return resultado;
    }
    
    
    public boolean actualizarInstancias(){
        boolean resultado = false;

        Session session = getSessionfactory().getCurrentSession();
        Transaction t = session.getTransaction();
        
	try {
		t.begin();
		session.flush();
		t.commit();
                resultado = true;
	} catch (Exception e) {
            System.out.println("No se pudo actualizar las instancias"+e);
        }

        return resultado;
    }
    
    public boolean contieneInstancia(Object xxx){
        
        boolean resultado = false;
                
        Session session = getSessionfactory().getCurrentSession();
        
        Transaction t = session.getTransaction();
        t.begin();
	try {
            resultado = session.contains(xxx);
            t.commit();
        } catch (Exception e) {
            System.out.println("No se pudo guardar la instancia "+e);
	}
        t.commit();
        return resultado;
        
    }
    
    public List<Reclamo> cargarReclamos(){
                String textoConsulta = "SELECT r FROM Reclamo r";
		
                Session session = getSessionfactory().getCurrentSession();
        
                Transaction t = session.getTransaction();
                t.begin();
		
                List<Reclamo> lista = session.createQuery(textoConsulta).list();

		t.commit();
		
                return lista;
    }
    
    public List<Reclamo> cargarReclamosEspecifico(int codigoEmpleado){
                String textoConsulta = "SELECT r FROM Reclamo r WHERE idempleadoexperto = '" + codigoEmpleado +  
                                                                        "'  AND  resuelto =  '" + false +  "'  " ;
		
                Session session = getSessionfactory().getCurrentSession();
        
                Transaction t = session.getTransaction();
                t.begin();
		
                List<Reclamo> lista = session.createQuery(textoConsulta).list();

		t.commit();
		
                return lista;
    }
    
    
    public List<EstadoDeReclamo> cargarEstadosDeReclamo(){
                String textoConsulta = "SELECT e FROM EstadoDeReclamo e" ;
		
                Session session = getSessionfactory().getCurrentSession();
        
                Transaction t = session.getTransaction();
                t.begin();
		
                List<EstadoDeReclamo> lista = session.createQuery(textoConsulta).list();

		t.commit();
		
                return lista;
    }
    
    
    
    
    public List<Servicio> cargarServicios(){
                String textoConsulta = "SELECT s FROM Servicio s";
		
                Session session = getSessionfactory().getCurrentSession();
        
                Transaction t = session.getTransaction();
                t.begin();
		List<Servicio> lista = session.createQuery(textoConsulta).list();

		t.commit();
		
                return lista;
    }
    
    public List<TipoDeReclamo> cargarTiposReclamo(){
                String textoConsulta = "SELECT t FROM TipoDeReclamo t";
		
                Session session = getSessionfactory().getCurrentSession();
        
                Transaction t = session.getTransaction();
                t.begin();
		List<TipoDeReclamo> lista = session.createQuery(textoConsulta).list();

		t.commit();
		
                return lista;
    }
    
    
    public List<EmpleadoExperto> cargarEmpleadoExperto(){
                String textoConsulta = "SELECT e FROM EmpleadoExperto e";
		
                Session session = getSessionfactory().getCurrentSession();
        
                Transaction t = session.getTransaction();
                t.begin();
		List<EmpleadoExperto> lista = session.createQuery(textoConsulta).list();

		t.commit();
		
                return lista;
    }
    
    public List<EmpleadoDeAtencion> cargarEmpleadoAtencion(){
                String textoConsulta = "SELECT e FROM EmpleadoDeAtencion e";
		
                Session session = getSessionfactory().getCurrentSession();
        
                Transaction t = session.getTransaction();
                t.begin();
		List<EmpleadoDeAtencion> lista = session.createQuery(textoConsulta).list();

		t.commit();
		
                return lista;
    }
    
    
    public List<Cliente> cargarClientes(){
                String textoConsulta = "SELECT c FROM Cliente c";
		
                Session session = getSessionfactory().getCurrentSession();
        
                Transaction t = session.getTransaction();
                t.begin();
		List<Cliente> lista = session.createQuery(textoConsulta).list();

		t.commit();
		
                return lista;
    }
    
    
}
